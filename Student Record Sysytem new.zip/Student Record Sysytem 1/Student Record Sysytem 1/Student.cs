﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Record_Sysytem_1
{
    internal class Student
    {
        public int StudentID { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Age { get; set; }
        public double Marks { get; set; }

        public Student() { }

        public Student(int id, string name, int age, double marks)
        {
            StudentID = id;
            Name = name;
            Age = age;
            Marks = marks;
        }

        public override string ToString()
        {
            return $"{StudentID} - {Name} - Age: {Age} - Marks: {Marks}";
        }
    }
}
