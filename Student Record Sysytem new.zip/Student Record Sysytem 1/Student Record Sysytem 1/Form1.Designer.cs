﻿namespace Student_Record_Sysytem_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtID = new TextBox();
            txtName = new TextBox();
            label3 = new Label();
            txtAge = new TextBox();
            label4 = new Label();
            txtMarks = new TextBox();
            label5 = new Label();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnSearch = new Button();
            dgvStudents = new DataGridView();
            lblCount = new Label();
            lblLoading = new ProgressBar();
            ((System.ComponentModel.ISupportInitialize)dgvStudents).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(394, 21);
            label1.Name = "label1";
            label1.Size = new Size(715, 48);
            label1.TabIndex = 0;
            label1.Text = "Student Record Management Application";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(158, 129);
            label2.Name = "label2";
            label2.Size = new Size(60, 25);
            label2.TabIndex = 1;
            label2.Text = "StdID:";
            // 
            // txtID
            // 
            txtID.Location = new Point(253, 126);
            txtID.Name = "txtID";
            txtID.Size = new Size(208, 31);
            txtID.TabIndex = 2;
            // 
            // txtName
            // 
            txtName.Location = new Point(1057, 129);
            txtName.Name = "txtName";
            txtName.Size = new Size(208, 31);
            txtName.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(962, 132);
            label3.Name = "label3";
            label3.Size = new Size(63, 25);
            label3.TabIndex = 3;
            label3.Text = "Name:";
            // 
            // txtAge
            // 
            txtAge.Location = new Point(1057, 206);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(208, 31);
            txtAge.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(962, 209);
            label4.Name = "label4";
            label4.Size = new Size(48, 25);
            label4.TabIndex = 5;
            label4.Text = "Age:";
            // 
            // txtMarks
            // 
            txtMarks.Location = new Point(253, 206);
            txtMarks.Name = "txtMarks";
            txtMarks.Size = new Size(208, 31);
            txtMarks.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(158, 209);
            label5.Name = "label5";
            label5.Size = new Size(64, 25);
            label5.TabIndex = 7;
            label5.Text = "Marks:";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = SystemColors.ActiveCaption;
            btnAdd.Location = new Point(165, 276);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(161, 43);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.SandyBrown;
            btnUpdate.Location = new Point(419, 276);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(161, 43);
            btnUpdate.TabIndex = 10;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.OrangeRed;
            btnDelete.Location = new Point(855, 276);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(161, 43);
            btnDelete.TabIndex = 11;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Silver;
            btnSearch.Location = new Point(1104, 276);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(161, 43);
            btnSearch.TabIndex = 12;
            btnSearch.Text = "SEARCH";
            btnSearch.UseVisualStyleBackColor = false;
            // 
            // dgvStudents
            // 
            dgvStudents.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStudents.Location = new Point(394, 415);
            dgvStudents.Name = "dgvStudents";
            dgvStudents.RowHeadersWidth = 62;
            dgvStudents.Size = new Size(656, 225);
            dgvStudents.TabIndex = 13;
            // 
            // lblCount
            // 
            lblCount.AutoSize = true;
            lblCount.Location = new Point(691, 351);
            lblCount.Name = "lblCount";
            lblCount.Size = new Size(0, 25);
            lblCount.TabIndex = 14;
            // 
            // lblLoading
            // 
            lblLoading.Location = new Point(165, 72);
            lblLoading.Name = "lblLoading";
            lblLoading.Size = new Size(1100, 34);
            lblLoading.TabIndex = 15;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1461, 673);
            Controls.Add(lblLoading);
            Controls.Add(lblCount);
            Controls.Add(dgvStudents);
            Controls.Add(btnSearch);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(txtMarks);
            Controls.Add(label5);
            Controls.Add(txtAge);
            Controls.Add(label4);
            Controls.Add(txtName);
            Controls.Add(label3);
            Controls.Add(txtID);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvStudents).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtID;
        private TextBox txtName;
        private Label label3;
        private TextBox txtAge;
        private Label label4;
        private TextBox txtMarks;
        private Label label5;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private Button btnSearch;
        private DataGridView dgvStudents;
        private Label lblCount;
        private ProgressBar lblLoading;
    }
}
