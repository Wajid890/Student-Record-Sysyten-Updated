using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Student_Record_Sysytem_1
{
    public partial class Form1 : Form
    {
        private List<Student> students = new List<Student>();
        private string dataFile = "students.json";

        public Form1()
        {
            InitializeComponent();
            LoadDataAsync(); // Load students on form load

            btnAdd.Click += btnAdd_Click;
            btnUpdate.Click += btnUpdate_Click;
            btnDelete.Click += btnDelete_Click;
            btnSearch.Click += btnSearch_Click;
        }

        // ==================== LOAD DATA ====================
        private async void LoadDataAsync()
        {
            lblLoading.Visible = true;
            dgvStudents.Enabled = false;

            await Task.Run(() =>
            {
                if (File.Exists(dataFile))
                {
                    string json = File.ReadAllText(dataFile);
                    students = JsonConvert.DeserializeObject<List<Student>>(json) ?? new List<Student>();
                }
            });

            dgvStudents.DataSource = null;
            dgvStudents.DataSource = students;
            lblCount.Text = $"Total Students: {students.Count}";

            lblLoading.Visible = false;
            dgvStudents.Enabled = true;
        }

        // ==================== SAVE DATA ====================
        private void SaveData()
        {
            try
            {
                string json = JsonConvert.SerializeObject(students, Newtonsoft.Json.Formatting.Indented);

                File.WriteAllText(dataFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving data: " + ex.Message);
            }
        }

        // ==================== ADD STUDENT ====================
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtID.Text);
                string name = txtName.Text;
                int age = int.Parse(txtAge.Text);
                double marks = double.Parse(txtMarks.Text);

                if (students.Any(s => s.StudentID == id))
                {
                    MessageBox.Show("Student ID already exists!");
                    return;
                }

                Student student = new Student(id, name, age, marks);
                students.Add(student);
                SaveData();
                dgvStudents.DataSource = null;
                dgvStudents.DataSource = students;
                lblCount.Text = $"Total Students: {students.Count}";

                MessageBox.Show("Student added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ==================== UPDATE STUDENT ====================
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtID.Text);
                Student student = students.FirstOrDefault(s => s.StudentID == id);
                if (student == null)
                {
                    MessageBox.Show("Student not found!");
                    return;
                }

                student.Name = txtName.Text;
                student.Age = int.Parse(txtAge.Text);
                student.Marks = double.Parse(txtMarks.Text);

                SaveData();
                dgvStudents.DataSource = null;
                dgvStudents.DataSource = students;
                MessageBox.Show("Student updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ==================== DELETE STUDENT ====================
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(txtID.Text);
                Student student = students.FirstOrDefault(s => s.StudentID == id);
                if (student == null)
                {
                    MessageBox.Show("Student not found!");
                    return;
                }

                students.Remove(student);
                SaveData();
                dgvStudents.DataSource = null;
                dgvStudents.DataSource = students;
                lblCount.Text = $"Total Students: {students.Count}";
                MessageBox.Show("Student deleted successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ==================== SEARCH STUDENT ====================
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchName = txtName.Text.ToLower();
            var results = students.Where(s => s.Name.ToLower().Contains(searchName)).ToList();
            dgvStudents.DataSource = null;
            dgvStudents.DataSource = results;
            lblCount.Text = $"Search Results: {results.Count}";
        }
    }
}
